import HeroSection from "@/components/fb/HeroSection";
import SocialProof from "@/components/fb/SocialProof";
import ValueSection from "@/components/fb/ValueSection";
import FinalCTA from "@/components/fb/FinalCTA";
import Footer from "@/components/fb/Footer";
import CoachSection from "@/components/fb/CoachSection";
import StickyCTA from "@/components/fb/StickyCTA";
import FAQSection from "@/components/fb/Faq";


const Index = () => {
  return (
    <main className="min-h-screen bg-background">
      <HeroSection />
      <SocialProof />
      <ValueSection />
      <CoachSection/>
      <FinalCTA />
      <FAQSection/>
      <StickyCTA/>
    </main>
  );
};

export default Index;
