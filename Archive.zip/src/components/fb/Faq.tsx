import { ChevronDown } from "lucide-react";
import { useState } from "react";

const faqs = [
  {
    q: "Is this another goal-setting workshop?",
    a: "No. This is execution architecture. We don’t talk about what you want — we design systems that make action inevitable.",
  },
  {
    q: "What if I procrastinate heavily?",
    a: "Perfect. This framework was built for intelligent procrastinators — people who overthink, delay, and still expect high standards from themselves.",
  },
  {
    q: "Is this beginner-friendly?",
    a: "Yes. Simple enough to start immediately — but structured deeply enough for high performers, founders, and leaders.",
  },
  {
    q: "Will I get the recording?",
    a: "Yes. Lifetime access to the full recording, frameworks, and updates.",
  },
];

const FAQSection = () => {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="bg-black pt-20 pb-16 md:pt-24 md:pb-24">

      {/* LINE SEPARATOR */}
      <div className="container mb-12">
        <div className="h-[4px] w-full bg-[#656565]/40" />
      </div>

      <div className="container max-w-3xl">

        {/* Header */}
        <h2 className="mb-10 font-heading2 text-3xl font-bold text-white md:text-4xl">
          Frequently Asked Questions
        </h2>

        {/* FAQ List */}
        <div className="space-y-3">
          {faqs.map((item, index) => (
            <div
              key={index}
              className="rounded-xl border border-white/10 bg-white/5"
            >
              <button
                onClick={() => setOpen(open === index ? null : index)}
                className="flex w-full items-center justify-between px-5 py-4 text-left"
              >
                <span className="text-sm md:text-base font-semibold text-white">
                  {item.q}
                </span>
                <ChevronDown
                  className={`h-4 w-4 text-white/60 transition-transform ${
                    open === index ? "rotate-180" : ""
                  }`}
                />
              </button>

              {open === index && (
                <div className="px-5 pb-5 pt-1 text-sm md:text-base text-white/70 leading-relaxed">
                  {item.a}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Closing trust line */}
        <p className="mt-10 text-sm text-white/50">
          Still unsure? If execution matters to you — this was built for you.
        </p>
      </div>
    </section>
  );
};

export default FAQSection;
