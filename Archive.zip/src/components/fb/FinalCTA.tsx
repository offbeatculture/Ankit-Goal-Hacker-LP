const FinalCTA = () => {
  return (
    <section className="relative bg-black py-8 md:py-28 bottom-0">

      {/* STRONG SEPARATOR FROM PREVIOUS SECTION */}
      <div
        className="absolute top-0 left-0 right-0 h-[2px]"
        style={{
          background:
            "linear-gradient(to right, transparent, #656565, transparent)",
        }}
      />

      <div className="container">
        <div className="mx-auto max-w-3xl text-left space-y-10">

          {/* Time framing */}
          <p className="text-xs md:text-sm font-semibold uppercase tracking-[0.35em] text-white/50">
            Imagine 12 Months From Today
          </p>

          {/* Headline */}
          <h2 className="font-heading2 text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight">
            Same ambitions.
            <br />
            Same intelligence.
            <br />
            <span className="text-white/60">
              But radically different execution.
            </span>
          </h2>

          {/* CORE INSIGHT + SYSTEM BLOCK */}
          <div className="relative rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8 space-y-6">

            {/* Accent line */}
            <div className="absolute left-0 top-6 h-[70%] w-[2px] bg-[#656565]" />

            {/* Insight */}
            <div className="space-y-2 pl-4">
              <p className="text-base md:text-lg text-white/70 leading-relaxed">
                The gap between where you are
                <br />
                and where you want to be
              </p>

              <p className="text-lg md:text-xl font-semibold text-white">
                is not time.
              </p>

              <p className="text-xl md:text-2xl font-bold text-white">
                It is{" "}
                <span className="text-[#fdc702]">
                  behavioral design.
                </span>
              </p>
            </div>

            {/* Divider */}
            <div className="h-px w-full bg-white/10" />

            {/* System framing */}
            <div className="space-y-1 pl-4">
              <p className="text-base md:text-lg text-white/70">
                Stop relying on motivation.
              </p>
              <p className="text-lg md:text-xl font-semibold text-white">
                Install systems instead.
              </p>
            </div>
          </div>

          {/* CTA */}
          <div className="pt-6 flex flex-col ">
            <a
              href="#form"
              className="
                relative inline-flex w-fit items-center justify-center
                rounded-full bg-[#fdc702] px-10 py-4
                text-sm md:text-base font-extrabold text-black
                transition hover:bg-yellow-300
                shadow-[0_0_32px_rgba(253,199,2,0.35)]
              "
            >
              {/* subtle pulse ring */}
              <span className="pointer-events-none absolute inset-0 rounded-full ring-2 ring-yellow-400/40 animate-final-cta" />
              Register for the Workshop
            </a>

           
          </div>
        </div>
      </div>

      {/* CTA pulse animation */}
      <style>{`
        @keyframes finalPulse {
          0% { transform: scale(1); opacity: 0.45; }
          70% { transform: scale(1.12); opacity: 0; }
          100% { transform: scale(1.12); opacity: 0; }
        }
        .animate-final-cta {
          animation: finalPulse 2.2s ease-out infinite;
        }
      `}</style>
    </section>
  );
};

export default FinalCTA;
